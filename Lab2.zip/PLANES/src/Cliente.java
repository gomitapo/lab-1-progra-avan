/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Acer
 */
public class Cliente {
    int minutos;
    String tipo;

    @Override
    public String toString() {
        return "Cliente{" + "minutos=" + minutos + ", tipo=" + tipo + '}';
    }

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Cliente(int minutos, String tipo) {
        this.minutos = minutos;
        this.tipo = tipo;
    }
    
}
