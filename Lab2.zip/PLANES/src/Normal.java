/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Acer
 */
public class Normal extends Preferencial {

    public int getCostofijo() {
        return costofijo;
    }

    public void setCostofijo(int costofijo) {
        this.costofijo = costofijo;
    }

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Normal(int costofijo, int minutos, String tipo) {
        super(costofijo, minutos, tipo);
    }
    
}
