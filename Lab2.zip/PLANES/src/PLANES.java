

/**
 *
 * @author Acer
 */

import java.util.Scanner;

public class PLANES{

    public static void main(String[] args){
    
        int valor;
        valor = 1;
        while (valor == 1){
        Scanner entrada = new Scanner(System.in);
        int cantidad;
        System.out.println("Indique la cantidad de minutos de conexión: ");
        cantidad = entrada.nextInt();
        while(cantidad < 0){
            System.out.println("indique una cantidad válida de minutos: ");
            cantidad = entrada.nextInt();
        }
        
        Scanner cosito = new Scanner(System.in);
        String tipo;
        
        
        System.out.println("indique el tipo de plan: ");
        tipo = entrada.next();
        
        
        if (tipo == "preferencial"){
            Preferencial cliente1 = new Preferencial(15000, cantidad, tipo );
            System.out.println("El monto a pagar es " + cliente1.Calculo(80)+ cliente1.costofijo);
            System.out.println("sus datos son" + cliente1);
        }
        
        else {Normal cliente1 = new Normal(7000, cantidad, tipo );
            System.out.println("El monto a pagar es " + (cliente1.Calculo(120)+ cliente1.costofijo));
            System.out.println("sus datos son" + cliente1);
        }
        
        Scanner valor1 = new Scanner(System.in);
        System.out.println("presione 2 para salir o 1 para continuar.");
        valor = valor1.nextInt();
        
    }
    
    
    
    
    }



}
    