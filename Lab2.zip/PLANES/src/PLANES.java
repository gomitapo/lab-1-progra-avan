

/**
 *
 * @author Acer
 */

import java.util.Scanner;

public class PLANES{

    public static void main(String[] args){
        String val1;
        String val2;
        val1 = "preferencial";
        val2 = "normal";
      
        int prefer;
        int normales;
        prefer = 0;
        normales = 0;
        int valor;
        valor = 1;
        while (valor == 1){
        Scanner entrada = new Scanner(System.in);
        int cantidad;
        System.out.println("Indique la cantidad de minutos de conexión: ");
        cantidad = entrada.nextInt();
        while(cantidad < 0){
            System.out.println("indique una cantidad válida de minutos: ");
            cantidad = entrada.nextInt();
        }
        
        Scanner cosito = new Scanner(System.in);
        String tipo;
        
        
        System.out.println("indique el tipo de plan: ");
        tipo = entrada.next();
        
        
        if (tipo.equals(val1)){
            
            
            
            Preferencial cliente1 = new Preferencial(15000, cantidad, tipo );
            prefer = prefer + 1;
            System.out.println("El monto a pagar es " + cliente1.Calculo(80)+ cliente1.costofijo);
            System.out.println("sus datos son" + cliente1);
            System.out.println("La cantidad de clientes Preferenciales es: " + prefer);
            System.out.println("La cantidad de clientes Normales es: " + normales);
        }
        
        else {
            Normal cliente1 = new Normal(7000, cantidad, tipo );
            normales = normales + 1;
            System.out.println("El monto a pagar es " + (cliente1.Calculo(120)+ cliente1.costofijo));
            System.out.println("sus datos son" + cliente1);
            System.out.println("La cantidad de clientes Normales es: " + normales);
            System.out.println("La cantidad de clientes Preferenciales es: " + prefer);
        }
        
        Scanner valor1 = new Scanner(System.in);
        System.out.println("presione 2 para salir o 1 para continuar.");
        valor = valor1.nextInt();
        
    }
    
    
    
    
    }



}
    