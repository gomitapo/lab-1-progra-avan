/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Acer
 */
public class Preferencial extends Cliente{

    public int getCostofijo() {
        return costofijo;
    }

    public void setCostofijo(int costofijo) {
        this.costofijo = costofijo;
    }

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Preferencial(int costofijo, int minutos, String tipo) {
        super(minutos, tipo);
        this.costofijo = costofijo;
    }

    int costofijo;
        
    
    
    public double Calculo(int costo) {
        double costototal = minutos * costo;
        return costototal;
    }
}




